// all imports
const { exec } = require('child_process');
const io = require('socket.io-client');
const os = require('os');
const path = require('path');
const debug = require('debug')('utk:client');
const ip = require('ip');
const jsonfile = require('jsonfile');
const _ = require('lodash');
let config = require('config');
const winston = require('winston');
// const Ajv = require('ajv');


winston.add(winston.transports.File, {
  filename: 'utk-client.log',
  maxsize: 5 * 1024,
  maxFiles: 10,
  prettyPrint: true,
  zippedArchive: true,
});


// global scope variable
const sysInfo = {};
const clientInfo = {};
const socket = io(`http://${config.server_host}:${config.server_port}`, {
  reconnection: true,
  reconnectionAttempts: Infinity,
  reconnectionDelay: 500,
});

function getPreActs() {
  return _
  .chain(config)
  .get(['action'])
  .mapValues((v, k, o) => {
    return k;
  })
  .value();
}

let predefinedActions = getPreActs();

function getSysInfo() {
  sysInfo.freemem = os.freemem();
  sysInfo.hostname = os.hostname();
  sysInfo.loadavg = os.loadavg();
  sysInfo.platform = os.platform();
  sysInfo.uptime = os.uptime();
  sysInfo.ip = ip.address();
}

function getClientInfo(clientIp = sysInfo.ip || 'unknownip', hostname = sysInfo.hostname || 'unknownhost') {
  clientInfo.name = `${clientIp}-${hostname}`;
  clientInfo.ip = clientIp;
}

function getDefaultConfigFilename() {
  return `${sysInfo.hostname}-${process.env.NODE_ENV || 'development'}.json`;
}

function appendConfigFile(settings = { test: 'test' }, callback) {
  const fullpath = path.resolve('config', getDefaultConfigFilename());
  const options = {
    spaces: 2,
  };

  jsonfile.readFile(fullpath, (err, obj) => {
    if (err) {
      callback(err);
    }
    jsonfile.writeFile(fullpath, settings, options, (writeErr) => {
      if (writeErr) {
        return callback(writeErr);
      }
      return callback();
    });
  });
}

// function sendSysInfo() {
//   getSysInfo();
//   socket.emit('sendSysInfo', sysInfo);
// }

function parsePsResult(psResult, args) {
  return _
  .chain(psResult)
  .split('\n')
  .dropRight()
  .map((v) => {
    const tmp = v.split(/\s+/);
    const o = _.zipObject(['user', 'pid', 'cpu', 'memory', 'vsz', 'rss', 'tty', 'stat', 'start', 'time'], tmp);
    o.command = _.takeRightWhile(tmp, i => _.indexOf(tmp, i) >= 10).join(' ');
    o.name = o.command;
    if (!_.isEmpty(args.configPns)) {
      args.configPns.forEach((pn) => {
        if (o.command.includes(pn)) {
          o.configPn = pn;
        }
      });
    }
    return o;
  })
  .value();
}

function addPredefinedIfNotExist(psResult) {
  const r = psResult;
  const configPns = Object.keys(_.get(config, ['process']));
  configPns.forEach((n) => {
    if (!_.find(psResult, { configPn: n })) {
      r.push({
        configPn: n,
        name: n,
        command: n,
      });
    }
  });
  return r;
}

function execDefaultCommand(action, callback, info) {
  debug('action, info', action, info);
  let command = '';
  if (action === predefinedActions.reboot) {
    debug(`action ${action} received`);
  } else if (action === predefinedActions.ps) {
    let greparg = [];
    let configPname = [];
    // first element of the args should be greparg(type: array)
    if (info.pid) {
      greparg.push(info.pid.toString());
      configPname.push(info.process);
    } else if (info.args) {
      greparg = greparg.concat(info.args[0]);
      configPname.push(info.process);
    } else if (!info.process) {
      const configAction = _.get(config, ['action', action]);
      if (!configAction) {
        callback('action not found');
      } else {
        greparg = greparg.concat(Object.keys(config.process));
        configPname = configPname.concat(Object.keys(config.process));
      }
    } else if (info.process) {
      greparg.push(info.process);
      configPname.push(info.process);
    }
    greparg = _
    .chain(greparg)
    .map(i => `[${i.substring(0, 1)}]${i.substring(1)}`)
    .join('\\|')
    .value();
    command = `ps aux | grep '${greparg}'`;
    winston.info('command: ', command);
    exec(command, (err, stdout, stderr) => {
      callback(err, {
        stdout: addPredefinedIfNotExist(parsePsResult(stdout, Object.assign(info, {
          configPns: configPname,
        }))),
        stderr,
      });
    });
  } else if (action === predefinedActions.getActions) {
    if (info.process) {
      callback(null, {
        stdout: config.process[info.process],
      });
    } else {
      callback(null, { stdout: config.action });
    }
  } else if (action === predefinedActions.kill) {
    if (info.pid) {
      exec(`kill -9 ${info.pid}`, (err, stdout, stderr) => {
        callback(err, { stdout, stderr });
      });
    } else {
      callback('pid required');
    }
  } else if (action === predefinedActions.start) {
    if (info.process) {
      exec(info.process, (err, stdout, stderr) => {
        callback(err, { stdout, stderr });
      });
    } else {
      callback('process required');
    }
  } else {
    callback(`${action} currently not implemented`);
  }
}

function execCommand(action, process, pid, callback) {
  winston.info(`action: ${action}, process: ${process}, pid: ${pid}`);
  const actionDefined = _.get(config, ['process', process, action]);
  execDefaultCommand(action, (err, data) => callback(err, data), {
    process: actionDefined !== undefined ? process : '',
    pid,
    args: actionDefined !== undefined ? actionDefined.command : undefined,
  });
}


// // pre-setting
// const ajv = new Ajv();
// const configSchema = {
//   "type": "object",
//   "properties": {
//   }
// };


// enter logical sequence
getSysInfo();
getClientInfo();

socket.on('connect', () => {
  socket.emit('setClientInfo', clientInfo);

//   socket.emit('setup', {
//     username: 'root',
//     host: '10.0.15.68',
//     password: '4pstvmis',
//   }, (err, stdout, stderr) => {
//     debug(err, stdout, stderr);
//   });

//   const d = {
//     name: clientInfo.name,
//     config: {
//       action: {
//         ps: {
//           description: 'pspsps',
//           command: null,
//         },
//       },
//     },
//   };
//   socket.emit('updateConfig', d, (err) => {
//     debug('err while updateConfig:', err);
//   });

//   socket.emit('action', { process: 'node', name: '10.0.15.179-imacarcher', action: 'ps',
//     ip: '10.0.15.179'
//     // pid: 3225,
//   }, (err,d) => {
//     debug('err from emitting action %O, result: %O', err, err);
//   });

//   socket.emit('sendSysInfo', ['10.0.15.179'], (err, r) => {
//     debug('r from sendSysInfo', r);
//   });
});

socket.on('action', (action, process, pid, callback) => {
  execCommand(action, process, pid, (err, data) => callback(err, data));
});

socket.on('sendSysInfo', (callback) => {
  getSysInfo();
  callback(null, sysInfo);
});

socket.on('updateConfig', (data, callback) => {
  appendConfigFile(data, (err) => {
    config = require('config');
    if (!config.util) {
      return callback('config.util not loaded');
    }
    config = config.util.loadFileConfigs();
    predefinedActions = getPreActs();
    return callback(err);
  });
});

socket.on('disconnect', () => {
});
