const app = require('http').createServer();
const io = require('socket.io')(app);
const debug = require('debug')('utk:server');
const Client = require('ssh2').Client;
const config = require('config');
const _ = require('lodash');
const winston = require('winston');

winston.add(winston.transports.File, {
  filename: 'utk-server.log',
  maxsize: 5 * 1024,
  maxFiles: 10,
  prettyPrint: true,
  zippedArchive: true,
});

app.listen(config.server_port);

const clients = {};

io.on('connection', (socket) => {
  /**
   * `setup` event listener
   *
   * @event setup
   * @param {Object} data
   * @example
   * data = { host: '10.0.15.68', username: 'root', password: '4pstvmis' };
   * @callback setupCallback
   * @example
   * callback(sysErr, actionErr, content);
   */

  /**
   * setupCallback
   *
   * @param {setupCallback} callback
   */
  socket.on('setup', (data, callback) => {
    const conn = new Client();
    conn.on('ready', () => {
      debug('ssh client :: ready');
      const setup = `rm -f utk.tar.gz && wget -O utk.tar.gz ${config.tar} && tar xOvf utk.tar.gz --wildcards utk*/setup | bash -`;

      function sendToWeb(event, d = []) {
        const socketWeb = io.sockets.connected[_.findKey(clients, { name: 'web' })];
        debug('socketweb:', typeof socketWeb, 'data:', d);
        if (socketWeb) {
          socketWeb.emit(event, d);
        }
      }

      function fireResult(rs = []) {
        if (rs.length !== 0) {
          sendToWeb('setupProgress', rs.shift());
        }
      }

      const tfire = _.throttle(fireResult, 1500);

      conn.exec(setup, (err, stream) => {
        callback(err, true);
        const result = [null, true, '', 0, '', ''];
        const resultStack = [];

        stream.on('close', (code, signal) => {
          debug(`Stream :: close :: code: ${code}, signal: ${signal}`);
          conn.end();
          result[1] = code === 0;
          socket.emit('setupResult', ...result);
        }).on('data', (res) => {
          const re = /installprocess(\d+\/\d+)\/(.*)\//i;
          const r = re.exec(res);
          if (r && r[1]) {
            result[3] = r[1];
            result[4] = r[2];
            result[5] = data.host;
            resultStack.push(result);
          }
          // tfire(resultStack);
          fireResult(resultStack);
          result[2] += res;
        }).stderr.on('data', (stderr) => {
          result[2] += stderr;
        });
      });
    }).connect(data);
  });

  /**
   * `updateConfig` event listener
   *
   * @event updateConfig
   * @param {Object} data
   * @example
   * data = { name: 'name', config: { action: { ps: { description: '' } } } };
   * @callback updateConfigCallback
   * @example
   * callback(err);
   */

  /**
   * updateConfigCallback
   *
   * @param {updateConfigCallback} callback
   */
  socket.on('updateConfig', (data, callback) => {
    debug('updateConfig with data: ', data);
    const tmpSocket = io.sockets.connected[_.findKey(clients, { ip: data.ip })] ||
      io.sockets.connected[_.findKey(clients, { name: data.name })];
    if (tmpSocket) {
      tmpSocket.emit('updateConfig', data.config, (err) => {
        debug('err from updateConfig: %O', err);
        callback(err);
      });
    } else {
      callback('cannot find socket with data:', data);
    }
  });

  /**
   * `action` event listener
   *
   * @event action
   * @param {Object} data
   * @example
   * data = { name: 'name', action: 'ps', process: '' };
   * @callback actionCallback
   * @example
   * callback(err, content);
   */

  /**
   * actionCallback
   *
   * @param {actionCallback} callback
   */
  socket.on('action', (data, callback) => {
    const tmpSocket = io.sockets.connected[_.findKey(clients, { ip: data.ip })] ||
      io.sockets.connected[_.findKey(clients, { name: data.name })];
    if (tmpSocket) {
      tmpSocket.emit('action', data.action, data.process, data.pid, (err, result) => {
        debug('err from action: %O, data from action: %O', err, result);
        if (err) {
          return callback(err);
        }
        return callback(err, result.stdout);
      });
    } else {
      debug('enter failed action, data: ', data);
      callback(`can not find socket with ${data}`);
    }
  });

  socket.on('setClientInfo', (clientInfo) => {
    clients[socket.id] = clientInfo;
    debug('clients: %O', clients);
    winston.info('set clientInfo with', clientInfo);
  });

//   function sendToWeb(event, data) {
//     const socketWeb = io.sockets.connected[_.findKey(clients, { name: 'web' })];
//     if (socketWeb) {
//       socketWeb.emit(event, data);
//     }
//   }

  socket.on('sendSysInfo', (ips, callback) => {
    const result = [];
    const sL = [];
    ips.forEach((item) => {
      const tmpSocket = io.sockets.connected[_.findKey(clients, { ip: item })];
      if (tmpSocket) {
        sL.push(tmpSocket);
      }
    });
    const getInfoList = (socketL, i) => {
      if (i >= socketL.length) {
        debug('result', result);
        callback(null, result);
      } else {
        socketL[i].emit('sendSysInfo', (err, r) => {
          result.push(r);
          getInfoList(socketL, i + 1);
        });
      }
    };
    getInfoList(sL, 0);
  });

  socket.on('disconnect', () => {
    debug('%O - %O has disconnected.', socket.id, clients[socket.id]);
    winston.info('%O has disconnected.', socket.id);
    delete clients[socket.id];
  });
});
