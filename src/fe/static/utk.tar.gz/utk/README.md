# Description
ump-tool-kit, utk (fake)

# Usage
1. utk.tar.gz
2. 解压，`# bash install`將進行server安裝
3. 同时项目包需要放在配好的路径

# Extra
1. `mkdir -p utk && tar xvf utk-master-*.tar.gz -C utk --strip-components 1 && tar czvf utk.tar.gz utk && rm -rf utk/ && rm utk-master-*.tar.gz`
